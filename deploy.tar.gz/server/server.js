const express = require('express');
const path = require('path');
const cors = require('cors');
const pool = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'admin123';

// 托管前端静态文件（index.html 在上级目录）
app.use(express.static(path.join(__dirname, '..')));

app.use(cors());
app.use(express.json());

// 管理端鉴权中间件
const authAdmin = (req, res, next) => {
  const key = req.query.key || req.headers['x-admin-key'];
  if (!key || key !== ADMIN_KEY) {
    return res.status(401).json({ error: '未授权，请提供有效的管理密钥' });
  }
  next();
};

// POST /api/franchise — 提交加盟表单
app.post('/api/franchise', async (req, res) => {
  try {
    const { name, phone, city } = req.body;

    // 必填校验
    if (!name || !name.trim()) {
      return res.status(400).json({ error: '请填写姓名' });
    }
    if (!phone || !phone.trim()) {
      return res.status(400).json({ error: '请填写联系电话' });
    }
    // 手机号格式校验 (中国大陆)
    const phoneRegex = /^1[3-9]\d{9}$/;
    if (!phoneRegex.test(phone.trim())) {
      return res.status(400).json({ error: '请输入有效的手机号码' });
    }
    if (!city || !city.trim()) {
      return res.status(400).json({ error: '请填写意向加盟城市' });
    }

    const [result] = await pool.execute(
      'INSERT INTO franchise_leads (name, phone, city) VALUES (?, ?, ?)',
      [name.trim(), phone.trim(), city.trim()]
    );

    res.json({
      success: true,
      message: '提交成功！我们的招商专员将在24小时内与您联系。',
      id: result.insertId
    });
  } catch (err) {
    console.error('插入数据失败:', err);
    res.status(500).json({ error: '服务器内部错误，请稍后再试' });
  }
});

// GET /api/franchise — 查询加盟线索（需管理密钥）
app.get('/api/franchise', authAdmin, async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, name, phone, city, created_at FROM franchise_leads ORDER BY created_at DESC LIMIT 100'
    );
    res.json(rows);
  } catch (err) {
    console.error('查询数据失败:', err);
    res.status(500).json({ error: '服务器内部错误' });
  }
});

// 健康检查
app.get('/api/health', (req, res) => {

// DELETE /api/franchise/:id — 删除加盟线索（需管理密钥）
app.delete('/api/franchise/:id', authAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await pool.execute(
      'DELETE FROM franchise_leads WHERE id = ?',
      [id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: '记录不存在' });
    }
    res.json({ success: true, message: '删除成功' });
  } catch (err) {
    console.error('删除数据失败:', err);
    res.status(500).json({ error: '服务器内部错误' });
  }
});
  res.json({ status: 'ok' });
});

app.listen(PORT, () => {
  console.log(`服务已启动: http://localhost:${PORT}`);
});
