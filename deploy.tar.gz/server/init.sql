-- 创建数据库
CREATE DATABASE IF NOT EXISTS hengtong CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE hengtong;

-- 加盟线索表
CREATE TABLE IF NOT EXISTS franchise_leads (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL COMMENT '姓名',
  phone VARCHAR(20) NOT NULL COMMENT '联系电话',
  city VARCHAR(50) NOT NULL COMMENT '意向加盟城市',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
  INDEX idx_created_at (created_at),
  INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='加盟招商线索';
