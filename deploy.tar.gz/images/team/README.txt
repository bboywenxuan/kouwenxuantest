专家团队图片（已有）:
├── ji-wanzhong.png   ✓ 季皖中
├── guo-lihe.png      ✓ 郭礼和
├── zhang-bin.png     ✓ 张斌
├── yang-jinbo.png    ✓ 杨金波
└── xie-fei.png       ← 需补充：谢飞博士

高管团队图片（需补充）:
├── zhang-xuesong.png  ← 张雪松（总经理）
├── ma-ming.png        ← 马明（联合创始人）
├── mo-hengnan.png     ← 莫衡南（副总经理/COO）
├── zhang-yong.png     ← 张勇（联合创始人/CFO）
└── huang-tiangang.png ← 黄天罡（联合创始人）

建议1:1正方形比例，300x300以上，PNG格式
